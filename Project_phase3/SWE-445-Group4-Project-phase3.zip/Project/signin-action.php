<?php

$url = "localhost";
$username = "root";
$password = "";
$db = "swe445_project";

$conn=mysqli_connect($url,$username,$password,$db);
    if(!$conn){
        die('Could not Connect');
	}
    
if(isset($_POST['signin-email'])&&isset($_POST['signin-password'])){
    $email=$_POST['signin-email'];
    $password=$_POST['signin-password'];

$sql = "SELECT * FROM customer WHERE email = '$email' AND password = MD5('$password')";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "Welcome " . $row["name"]."<br>";
  }
} else {
  echo '<script>alert("Invalid Login Credentials")</script>';
  
  
}

mysqli_close($conn);

}

?>