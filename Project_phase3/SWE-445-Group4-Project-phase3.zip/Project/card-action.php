<?php

$url = "localhost";
$username = "root";
$password = "";
$db = "swe445_project";

$conn=mysqli_connect($url,$username,$password,$db);
    if(!$conn){
        die('Could not Connect');
	}
    
if(isset($_POST['cardNumber'])&&isset($_POST['cardName'])&&isset($_POST['cardDate'])&&isset($_POST['cardCCV'])){
$cardNumber=$_POST['cardNumber'];
$cardName=$_POST['cardName'];
$cardDate=$_POST['cardDate'];
$cardCCV=$_POST['cardCCV'];


$sql="INSERT INTO `card` (`card_number`, `expiration_date`, `secret_num`, `holders_name`, `c_id`) VALUES (MD5('$cardNumber'), '$cardDate', MD5('$cardCCV'), '$cardName', '1')";
if(mysqli_query($conn,$sql)){
    echo 'Card succesfully added';
}else{
    echo 'error: '.mysqli_error($conn);
}
}
?>