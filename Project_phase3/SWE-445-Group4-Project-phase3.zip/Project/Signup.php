<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Register - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/css/pincode-input-mask.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
</head>

<body class="bg-gradient-primary" style="color: #858796;background: #ced4da;">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center" style="color: #737272;margin-top: 25px;">Dhahran E-Shopping System</h1>
            </div>
        </div>
        <div class="card shadow-lg o-hidden border-0 my-5">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-flex">
                        <div class="flex-grow-1 bg-register-image" style="background: url(&quot;assets/img/ithra.jpg&quot;);background-size: 100%;"></div>
                    </div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h4 class="text-dark mb-4">Sign-Up with Us!</h4>
                            </div>
                            <form class="user" action="signup-action.php" method="POST">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0"><input class="form-control form-control-user" type="text" id="signupName" placeholder="Full Name" name="name" pattern="^[a-zA-Z\s]{2,50}$" title="Enter first and last name" required=""></div>
                                    <div class="col-sm-6"><input class="form-control form-control-user" type="number" id="signupPhone" placeholder="Phone Number" name="phone" pattern="^[\d]{10}$" title="05********" required=""></div>
                                </div>
                                <div class="form-group"><input class="form-control form-control-user" type="email" id="signupEmail" aria-describedby="emailHelp" placeholder="Email Address" name="email" pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$" title="example@gmail.com" required=""></div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0"><input class="form-control form-control-user" type="password" id="signupPwd" placeholder="Password" name="password" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,32}$" title="At least one capital and small letter and number , has to be minimum of 8 characters" required=""></div>
                                    <div class="col-sm-6"><input class="form-control form-control-user" type="password" id="signupPwd2" placeholder="Retype Password" name="password_repeat"  pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,32}$" title="Repeat the same password" required=""></div><span class="text-center d-xl-flex justify-content-xl-center" style="font-size: 14px;">&nbsp; &nbsp; &nbsp; &nbsp;Passwords must have at least one uppercase and one lowercase and one digit.&nbsp;</span>
                                </div><button class="btn btn-primary btn-block text-white btn-user" type="submit" name="submit">Register Account</button>
                                <hr>
                            </form>
                            <div class="text-center"></div>
                            <div class="text-center"><a class="small" href="Signin.php">Already have an account? Login!</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="validate.js"></script>
</body>

</html>