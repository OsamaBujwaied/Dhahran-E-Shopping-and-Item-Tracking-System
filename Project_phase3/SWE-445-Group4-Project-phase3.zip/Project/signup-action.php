<?php

$url = "localhost";
$username = "root";
$password = "";
$db = "swe445_project";

$conn=mysqli_connect($url,$username,$password,$db);
    if(!$conn){
        die('Could not Connect');
	}
    
if(isset($_POST['name'])&&isset($_POST['email'])&&isset($_POST['phone'])&&isset($_POST['password'])&&isset($_POST['password_repeat'])){
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$phone=$_POST['phone'];

if($password != $_POST['password_repeat']){
    echo '<script>alert("Welcome to Geeks for Geeks")</script>';
}


$sql="INSERT INTO `customer` (`c_id`, `name`, `email`, `password`, `phone`) VALUES (NULL, '$name', '$email', MD5('$password'), '$phone')";
if(mysqli_query($conn,$sql)){
    echo 'Successfully Signed up';
}else{
    echo 'error: '.mysqli_error($conn);
}
}
?>