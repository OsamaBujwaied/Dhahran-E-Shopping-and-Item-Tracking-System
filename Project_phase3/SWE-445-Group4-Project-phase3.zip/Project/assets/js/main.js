$('#pincode-input1').pincodeInput({inputs:4, hidedigits:true});
